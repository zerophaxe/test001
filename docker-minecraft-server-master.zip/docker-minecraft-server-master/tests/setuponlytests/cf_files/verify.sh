mc-image-helper assert fileExists "/data/mods/architectury-*-fabric.jar"
mc-image-helper assert fileExists "/data/mods/Clumps-fabric-*.jar"
mc-image-helper assert fileExists "/data/mods/fabric-api-*.jar"
mc-image-helper assert fileExists "/data/mods/jei-*-fabric-*.jar"

