[[ $CF_API_KEY ]] || exit 1
