mc-image-helper assert fileExists mods/architectury-5.7.28-fabric.jar
