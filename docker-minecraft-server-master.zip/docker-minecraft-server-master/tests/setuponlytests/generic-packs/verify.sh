mc-image-helper assert fileExists one.txt mods/two.txt
mc-image-helper assert fileExists config/opt.yml