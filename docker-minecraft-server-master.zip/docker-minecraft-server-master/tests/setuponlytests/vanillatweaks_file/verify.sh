mc-image-helper assert fileExists "/data/world/datapacks/afk*"
mc-image-helper assert fileExists "/data/world/datapacks/graves*"
mc-image-helper assert fileExists "/data/world/datapacks/VanillaTweaks_*"
mc-image-helper assert fileExists "/data/resourcepacks/VanillaTweaks_*"
