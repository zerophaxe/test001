mc-image-helper assert fileExists "/data/NanoLimbo*.jar"
mc-image-helper assert fileExists "/data/settings.yml"
