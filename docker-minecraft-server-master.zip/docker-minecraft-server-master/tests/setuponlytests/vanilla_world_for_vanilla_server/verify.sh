mc-image-helper assert fileExists world/level.dat && \
mc-image-helper assert fileExists world/DIM-1/some_nether_file && \
mc-image-helper assert fileExists world/DIM1/some_end_file
