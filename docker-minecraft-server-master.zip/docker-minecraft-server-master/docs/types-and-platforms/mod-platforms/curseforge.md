# Manual CurseForge server packs

!!! warning "Deprecated"

    This mod platform type is deprecated. Please use [AUTO_CURSEFORGE](auto-curseforge.md) for new deployments.

Enable this server mode by setting `MODPACK_PLATFORM`, `MOD_PLATFORM` or `TYPE` to "CURSEFORGE" along with the following specific variables.

You need to specify a modpack to run, using the `CF_SERVER_MOD` environment
variable. A CurseForge server modpack is available together with its respective
client modpack at <https://www.curseforge.com/minecraft/modpacks> .

Now you can add a `-e CF_SERVER_MOD=name_of_modpack.zip` to your command-line.
```shell
docker run -d --pull=always -v /path/on/host:/data -e TYPE=CURSEFORGE \
    -e CF_SERVER_MOD=SkyFactory_4_Server_4.1.0.zip \
    -p 25565:25565 -e EULA=TRUE --name mc itzg/minecraft-server
```
If you want to keep the pre-download modpacks separate from your data directory,
then you can attach another volume at a path of your choosing and reference that.
The following example uses `/modpacks` as the container path as the pre-download area:
```shell
docker run -d --pull=always -v /path/on/host:/data \
    -v /path/to/modpacks:/modpacks -e TYPE=CURSEFORGE \
    -e CF_SERVER_MOD=/modpacks/SkyFactory_4_Server_4.1.0.zip \
    -p 25565:25565 -e EULA=TRUE --name mc itzg/minecraft-server
```
### Modpack data directory

By default, CurseForge modpacks are expanded into the sub-directory `/data/FeedTheBeast` and executed from there. (The default location was chosen for legacy reasons, when Curse and FTB were maintained together.)

The directory can be changed by setting `CF_BASE_DIR`, such as `-e CF_BASE_DIR=/data`.

### Buggy start scripts

Some modpacks have buggy or overly complex start scripts. You can avoid using the bundled start script and use this image's standard server-starting logic by adding `-e USE_MODPACK_START_SCRIPT=false`.

### Fixing "unable to launch forgemodloader"

If your server's modpack fails to load with an error [like this](https://support.feed-the-beast.com/t/cant-start-crashlanding-server-unable-to-launch-forgemodloader/6028/2):

    unable to launch forgemodloader

then you apply a workaround by adding this to the run invocation:

    -e FTB_LEGACYJAVAFIXER=true
